"""
Tests package for STAVKI value betting system.
"""

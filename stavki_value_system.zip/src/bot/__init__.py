"""
Telegram bot package for STAVKI betting system.
"""

from .telegram_bot import StavkiBot

__all__ = ["StavkiBot"]

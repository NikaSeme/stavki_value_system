"""State management package for deduplication and persistence."""

__all__ = []
